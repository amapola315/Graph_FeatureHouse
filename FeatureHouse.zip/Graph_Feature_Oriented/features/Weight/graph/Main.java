package graph;

import java.util.Scanner;

class Main {
 
            System.out.print("enter weight: ");
            int weight = scanner.nextInt();
            graph.addEdge(from, to, weight);
        }

        // show graph structure
      
        for (Node node : graph.getNodes()) {
            System.out.print("Node " + node.getLabel() + " --> ");
            for (Edge edge : node.getNeighbors()) {
                System.out.print(edge.getDestination().getLabel() + " (" + edge.getWeight() + ") | ");
            }
            System.out.println();
        }

     scanner.close();
    
}
