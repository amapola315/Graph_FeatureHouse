class Main {

    String more;
    
    Main() { more = "more"; }
 
    void print() {
        original();
        System.out.println( more );
    }

}