class Main {

    String last;
    
    Main() { last = "last"; }
 
    void print() {
        original();
        System.out.println( last );
    }
}